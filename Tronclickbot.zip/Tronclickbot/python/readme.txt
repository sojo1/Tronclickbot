its python downgrading  file 
but now ive updated the script to make it work on any python version 

EXAON TECH 